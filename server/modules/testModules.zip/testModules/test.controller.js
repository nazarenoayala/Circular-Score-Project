import testDal from "./test.dal.js";

class TestController {

  selectAllTest = async (req, res) => {

    try {
      
      let result = await testDal.selectAllTest();

      res.status(200).json({message: 'Ruta ok', result});


    } catch (error) {
      
      res.status(500).json('No ok');
      console.log(error);
    }

  }

  disableTest = async (req, res) => {

    const {id} = req.params;
    let values = [id];

    try {

      let result = await testDal.disableTest(values);

      res.status(200).json({message: 'Test deshabilitado', result});

    } catch (error) {

      console.log(error);
      res.status(500).json(error);

    }

  }

  enableTest = async (req, res) => {

    const {id} = req.params;
    let value = [id];

    try {

      let result = await testDal.enableTest(value);

      res.status(200).json({message: 'Test habilitado', result});
      
    } catch (error) {
      console.log(error);
      res.status(500).json(error);
    }
  }

  createTest = async (req, res) =>{

    const {id} = req.params;
    const {test_name} = req.body;
    const test_image = `ods${id}.svg`;
    const values = [id, test_name, test_image];

    try {
      
      const result = await testDal.createTest(values);

      res.status(200).json({message: 'Test creado', result});

    } catch (error) {
      console.log(error);
      res.status(500).json(error);
    }
  }

  addTestQuestion = async (req, res) => {

    const {id} = req.params;
    const {question_id, text} = req.body;
    const values = [id, question_id, text];

    try {
      
      const result = await testDal.addTestQuestion(values);
      res.status(200).json({message: 'Pregunta añadida', result});
    } catch (error) {
      console.log(error);
      res.status(500).json(error);
    }

  }

  deleteTest = async (req, res) => {

    const {id} = req.params;

    try {
      
      const result = await testDal.deleteTest([id]);
      res.status(200).json({message: 'Visibilidad del test desactivada', result});
    } catch (error) {
      console.log(error);
      res.status(500).json(error);
    }
  }
}

export default new TestController();